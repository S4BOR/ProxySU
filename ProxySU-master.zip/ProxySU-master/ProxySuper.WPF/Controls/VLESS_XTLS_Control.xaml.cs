﻿using System.Windows.Controls;

namespace ProxySuper.WPF.Controls
{
    /// <summary>
    /// VLESS_XTLS_Control.xaml 的交互逻辑
    /// </summary>
    public partial class VLESS_XTLS_Control : UserControl
    {
        public VLESS_XTLS_Control()
        {
            InitializeComponent();
        }
    }
}
