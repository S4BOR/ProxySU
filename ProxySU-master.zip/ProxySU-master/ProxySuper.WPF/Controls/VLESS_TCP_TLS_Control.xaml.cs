﻿using System.Windows.Controls;

namespace ProxySuper.WPF.Controls
{
    /// <summary>
    /// VLESS_TCP_TLS_Control.xaml 的交互逻辑
    /// </summary>
    public partial class VLESS_TCP_TLS_Control : UserControl
    {
        public VLESS_TCP_TLS_Control()
        {
            InitializeComponent();
        }
    }
}
