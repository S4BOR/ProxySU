﻿using System.Windows.Controls;

namespace ProxySuper.WPF.Controls
{
    /// <summary>
    /// HostControl.xaml 的交互逻辑
    /// </summary>
    public partial class HostControl : UserControl
    {
        public HostControl()
        {
            InitializeComponent();
        }
    }
}
