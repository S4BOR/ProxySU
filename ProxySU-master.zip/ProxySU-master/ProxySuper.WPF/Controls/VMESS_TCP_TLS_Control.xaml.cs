﻿using System.Windows.Controls;

namespace ProxySuper.WPF.Controls
{
    /// <summary>
    /// VMESS_TCP_TLS_Control.xaml 的交互逻辑
    /// </summary>
    public partial class VMESS_TCP_TLS_Control : UserControl
    {
        public VMESS_TCP_TLS_Control()
        {
            InitializeComponent();
        }
    }
}
