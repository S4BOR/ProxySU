﻿using System.Windows.Controls;

namespace ProxySuper.WPF.Controls
{
    /// <summary>
    /// VLESS_KCP_Control.xaml 的交互逻辑
    /// </summary>
    public partial class VLESS_KCP_Control : UserControl
    {
        public VLESS_KCP_Control()
        {
            InitializeComponent();
        }
    }
}
