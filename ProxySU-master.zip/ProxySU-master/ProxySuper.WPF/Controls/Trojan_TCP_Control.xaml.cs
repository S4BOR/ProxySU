﻿using System.Windows.Controls;

namespace ProxySuper.WPF.Controls
{
    /// <summary>
    /// Trojan_TCP_Control.xaml 的交互逻辑
    /// </summary>
    public partial class Trojan_TCP_Control : UserControl
    {
        public Trojan_TCP_Control()
        {
            InitializeComponent();
        }
    }
}
