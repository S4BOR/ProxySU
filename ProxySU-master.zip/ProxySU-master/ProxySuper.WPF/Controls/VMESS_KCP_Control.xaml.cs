﻿using System.Windows.Controls;

namespace ProxySuper.WPF.Controls
{
    /// <summary>
    /// VMESS_KCP_Control.xaml 的交互逻辑
    /// </summary>
    public partial class VMESS_KCP_Control : UserControl
    {
        public VMESS_KCP_Control()
        {
            InitializeComponent();
        }
    }
}
