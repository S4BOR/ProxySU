﻿using System.Windows.Controls;

namespace ProxySuper.WPF.Controls
{
    /// <summary>
    /// ShadowSocksClientInfoControl.xaml 的交互逻辑
    /// </summary>
    public partial class ShadowSocksControl : UserControl
    {
        public ShadowSocksControl()
        {
            InitializeComponent();
        }
    }
}
