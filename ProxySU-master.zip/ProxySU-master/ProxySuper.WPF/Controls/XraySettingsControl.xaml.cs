﻿using System.Windows.Controls;

namespace ProxySuper.WPF.Controls
{
    /// <summary>
    /// XraySettingsControl.xaml 的交互逻辑
    /// </summary>
    public partial class XraySettingsControl : UserControl
    {
        public XraySettingsControl()
        {
            InitializeComponent();
        }
    }
}
