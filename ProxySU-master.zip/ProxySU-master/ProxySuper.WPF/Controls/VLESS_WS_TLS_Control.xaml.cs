﻿using System.Windows.Controls;

namespace ProxySuper.WPF.Controls
{
    /// <summary>
    /// VLESS_WS_TLS_Control.xaml 的交互逻辑
    /// </summary>
    public partial class VLESS_WS_TLS_Control : UserControl
    {
        public VLESS_WS_TLS_Control()
        {
            InitializeComponent();
        }
    }
}
