﻿using MvvmCross.Platforms.Wpf.Presenters.Attributes;
using MvvmCross.Platforms.Wpf.Views;

namespace ProxySuper.WPF.Views
{
    [MvxWindowPresentation]
    public partial class NaiveProxyConfigView : MvxWindow
    {
        public NaiveProxyConfigView()
        {
            InitializeComponent();
        }
    }
}
