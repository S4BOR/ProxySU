﻿using MvvmCross.Platforms.Wpf.Presenters.Attributes;
using MvvmCross.Platforms.Wpf.Views;

namespace ProxySuper.WPF.Views
{
    [MvxWindowPresentation]
    public partial class ShareLinkView : MvxWindow
    {
        public ShareLinkView()
        {
            InitializeComponent();
        }
    }
}
