﻿using MvvmCross.Platforms.Wpf.Presenters.Attributes;
using MvvmCross.Platforms.Wpf.Views;

namespace ProxySuper.WPF.Views
{
    [MvxWindowPresentation]
    public partial class TrojanGoEditorView : MvxWindow
    {
        public TrojanGoEditorView()
        {
            InitializeComponent();
        }
    }
}
