﻿namespace ProxySuper.Core.Models.Hosts
{
    public enum LoginSecretType
    {
        Password = 0,
        PrivateKey = 1
    }
}
