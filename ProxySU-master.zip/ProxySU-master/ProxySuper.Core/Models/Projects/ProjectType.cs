﻿namespace ProxySuper.Core.Models.Projects
{
    public enum ProjectType
    {
        Xray = 0,
        TrojanGo = 1,
        NaiveProxy = 2,
        Brook = 3,
        V2ray = 4,
        MTProtoGo = 5,
        Hysteria = 6,
    }
}
