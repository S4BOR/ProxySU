﻿namespace ProxySuper.Core.Models.Projects
{
    public enum BrookType
    {
        server,
        wsserver,
        wssserver,
        socks5
    }
}
